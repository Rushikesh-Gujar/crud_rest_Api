package com.stud.service;

import java.util.List;

import com.stud.entity.Student;

public interface StudentService {

	List<Student> getAllStudent();
	
	Student saveStudents(Student student);
	
	Student getStudentById(Long id);
	Student updateStudent(Student student);
}
