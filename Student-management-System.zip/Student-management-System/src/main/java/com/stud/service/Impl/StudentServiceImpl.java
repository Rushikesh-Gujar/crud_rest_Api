package com.stud.service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.stud.entity.Student;
import com.stud.repository.StudentRepository;
import com.stud.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
	private StudentRepository studentrepository;
	private Object student;
	
	
	
	public StudentServiceImpl(StudentRepository studentrepository) {
		super();
		this.studentrepository = studentrepository;
	}



	public List<Student> getAllStudent() {
		return (List<Student>) studentrepository.findAll();
	}



	@Override
	public Student saveStudents(Student student) {
		return studentrepository.save(student);
	}



	@Override
	public Student getStudentById(Long id) {
	
		return studentrepository.findById(id).get();
	}



	@Override
	public Student updateStudent(Student student) {
		return studentrepository.save(student);
	}

	
	
}
